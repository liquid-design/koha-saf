droplets = {
  "koha-saf-prod" = {
    name      = "bib.marxisme.be"
    region    = "ams3"
    size      = "s-2vcpu-2gb"
    image     = "debian-12-x64"
    tags      = ["koha", "prod"]
    user_data = <<-EOF
    #cloud-config
    packages:
      - htop
      - git
    users:
      - name: ansible
        sudo: ALL=(ALL) NOPASSWD:ALL
        shell: /bin/bash
        lock_passwd: false
        passwd: "$6$DpwMNhLPWjS.EhFW$uJpKn.ph3f4msYQga94aZPjHK3xtn/gpBskyTnWSJGnxQsCzwTfJ8gXwFjuf.csa3MrQbFAuQs4vM71ZDGMvd."
        ssh_authorized_keys:
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMlQ2yd4L+uqNDbks1AeHmgohojjprVks1QJlPd3DnhL ansible
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK/xoi0JMQiK4Qp2vnE4vCYTlLXX3GPA6NpAzgMzdwuz sander@Elss-Laptop.local
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAKMdO3JrvmB4g/YTD9yXEq09LhySJ5itMvliMVhq1RS sander@liquid-design.be
  EOF
  }


  "koha-saf-test" = {
    name      = "bib-test.marxisme.be"
    region    = "ams3"
    size      = "s-2vcpu-2gb"
    image     = "debian-12-x64"
    tags      = ["koha", "test"]
    user_data = <<-EOF
    #cloud-config
    packages:
      - htop
      - git
    users:
      - name: ansible
        sudo: ALL=(ALL) NOPASSWD:ALL
        shell: /bin/bash
        lock_passwd: false
        passwd: "$6$DpwMNhLPWjS.EhFW$uJpKn.ph3f4msYQga94aZPjHK3xtn/gpBskyTnWSJGnxQsCzwTfJ8gXwFjuf.csa3MrQbFAuQs4vM71ZDGMvd."
        ssh_authorized_keys:
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMlQ2yd4L+uqNDbks1AeHmgohojjprVks1QJlPd3DnhL ansible
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK/xoi0JMQiK4Qp2vnE4vCYTlLXX3GPA6NpAzgMzdwuz sander@Elss-Laptop.local
          - ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAKMdO3JrvmB4g/YTD9yXEq09LhySJ5itMvliMVhq1RS sander@liquid-design.be
  EOF
  }
}
